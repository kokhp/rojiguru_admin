import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from '../login.service'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  email: FormControl;
  password: FormControl;

  constructor(
    private router: Router,
    private fb: FormBuilder,
    private _loginService: LoginService
  ) { }

  ngOnInit() {

    this.email = new FormControl('', Validators.required),
    this.password = new FormControl('', Validators.required)

    this.loginForm = this.fb.group({
      email: this.email,
      password: this.password
    });
  }

  onLoginClick() {
    if (this.loginForm.invalid) {
      console.log("form is invalid")
      return;
    }
    const data = {
      email: this.email.value,
      password: this.password.value
    }

    this._loginService.login(data)
      .subscribe(
        response => { 
          console.log("Success!", response);
          localStorage.setItem('token', response.data.token);
          this.router.navigate(['/'])
          console.log(response.data.token)
        },
        error => console.log("Failed", error.statusText)
      )

    console.log(data);
  }
}