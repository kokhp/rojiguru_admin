import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-user-detail',
  templateUrl: './user-detail.component.html',
  styleUrls: ['./user-detail.component.scss']
})
export class UserDetailComponent implements OnInit {
  id;
  UserData;
  EducationDetails;
  JobExperience;
  edFields = ['Course', 'Year', 'CGP', 'University'];
  cvfile: string;

  constructor(private apiService: ApiService, private route: ActivatedRoute) {
    this.route.params.subscribe(params => {
      this.id = params['id'];
    });
  }

  ngOnInit() {
    this.getById();
  }

  keys(item): Array<any> {
    return Object.keys(item);
  }

  cvLogic() {
    this.apiService.getCV(this.id).subscribe(
      (data: any) => {
        this.apiService.downLoadFile(data, this.cvfile)
      }
    );
  };

  getById() {
    this.apiService.getByID(this.id).subscribe((data: any) => {
      this.UserData = data.data.user;
      console.log(this.UserData);

      this.UserData.dob = this.UserData.dob.split("T")[0];
      this.EducationDetails = JSON.parse(this.UserData.education);
      this.JobExperience = JSON.parse(this.UserData.jobexp);
      this.UserData.languages = ['Gujarati', 'Kannad', 'Marathi', 'English'];
      this.cvfile = JSON.parse(this.UserData.name) + '.' + this.UserData.cv.split('\\')[1].split('.')[1];

      // remove this prototype of educational details
      /*
      this.EducationDetails = [
        {
          course: "Mechanical",
          passingYear: 2010,
          cpa: 10,
          university: "UNI",
        },
        {
          course: "Highschool",
          passingYear: 2008,
          cpa: 10,
          school: "MySchool"
        }
      ]
      */

    });
  }
}